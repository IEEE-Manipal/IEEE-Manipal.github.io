$(document).ready(function() { // when the HTML document is ready, execute the following

	$('#butr1d1').click(function(){	// when element with id butr1d1 is clicked
		var status;	// define a variable 'status' which will store status of LED
		if($('#butr1d1').val() == "off") { // if VALUE of button is OFF ie, the LED is OFF and we click
			$('#imgr1d1').attr('src','images/bulbon.png'); // change image to bulbon
			$("#butr1d1").val("on"); // change value to ON
			$("#butr1d1").text("OFF"); // change text to OFF
			status = 1; // make status 1 ie. led is ON
		} else if($('#butr1d1').val() == "on") {
			$('#imgr1d1').attr('src','images/bulboff.png');
			$("#butr1d1").val("off");
			$("#butr1d1").text("ON");
			status = 0;
		}

	$.get('php/room1.php', { device1:status },function(data){}); // make a GET request to the room1.php file
		console.log(data); // print the response on the console. View it in developer's mode
	});

	// same for room2
	$('#butr2d1').click(function(){
		var status;
		if($('#butr2d1').val() == "off") {
			$('#imgr2d1').attr('src','images/bulbon.png');
			$("#butr2d1").val("on");
			$("#butr2d1").text("OFF");
			status = 0;
		} 
		else if($('#butr2d1').val() == "on") {
			$('#imgr2d1').attr('src','images/bulboff.png');
			$("#butr2d1").val("off");
			$("#butr2d1").text("ON");
			status = 1;
		}

		$.get('php/room2.php', { device1:status }, function(data){});
	});

	// get sensor value from respective files
	$('#butMois').click(function(){ // when button is clicked
		jQuery.get('php/mois.txt', function(data) { //  make GET request to the mois.txt file which contains moisture sensor value
				$("#dataMois").text(data+"%"); // select the element with id as dataMois and change its text to the data received
		});
	});

	// same as above
	$('#butTemp').click(function(){
		jQuery.get('php/temp.txt', function(data) {
				$("#dataTemp").text(data+"C");
		});
	});
});