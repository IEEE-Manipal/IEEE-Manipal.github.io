<?php

$msg = $_GET['device1']; // get value of parameter 'device1' using GET request and store it in variable msg

echo "Status of device is : " . $msg; // this is the response to the request

$myfile = fopen("room1.txt", "w") or die("Unable to open file!"); // open room1.txt file in WRITE mode using "w". If the file doesn't open, die statement will print the error line on screen

fwrite($myfile, $msg); // after file is opened, write the msg variable inside file

fclose($myfile); // close the file
?>