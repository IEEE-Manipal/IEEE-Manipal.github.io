package com.example.bhawesh96.workshop;

//imports
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

//volley specific imports. Volley is a library we use for Internet Connectivity. To deal with HTTP
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

//defining a public class. Class name should be same as file name. INHERITS the class AppCompatActivity using EXTENDS
public class RoomActivity extends AppCompatActivity {

    TextView status_led, status_mois;    // to reference the TextView element in the GUI
    Button button_led, button_mois;  // to reference the button element in the GUI
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room); // to refrence the LAYOUT file corresponding to this ACTIVITY

        status_led = (TextView) findViewById(R.id.textView_status); // assign value to the refrence variable of TextView
        button_led = (Button) findViewById(R.id.button_led);    // assign value to the refrence variable of button
        status_mois = (TextView) findViewById(R.id.textView_mois); // assign value to the refrence variable of TextView
        button_mois = (Button) findViewById(R.id.button_mois);    // assign value to the refrence variable of button

        button_led.setOnClickListener(new View.OnClickListener() { // listens to click of button
            @Override
            public void onClick(View view) { // when button is clicked

                Toast.makeText(RoomActivity.this, "Button Clicked", Toast.LENGTH_LONG).show();  // display BUTTON CLICKED message

                String button_status = null; // initialise the value of string to NULL

                // if the button text is OFF ie. the LED is ON and we click on it, change text to ON and make status 0. Logic similar to JQuery
                if(button_led.getText().toString().equals("OFF")) { // extract the text of button using getText(). Convert to string using toString(). Compare using equals();
                    button_led.setText("ON");
                    button_status = "0";
                } else if(button_led.getText().toString().equals("ON")) { // else // if the button text is ON ie. the LED is OFF and we click on it, change text to OFF and make status 1
                    button_led.setText("OFF");
                    button_status = "1";
                }

                // Volley method (function)
                RequestQueue queue = Volley.newRequestQueue(RoomActivity.this); // build the request queue. The queue which will execute all the requests
                String url ="http://your_ip/homeAutomation/php/room1.php?device1="+button_status; // define the URL which you want to hit. CONCATENATE the button_status varialble

                // the effective string becomes http://your_IP/homeAutomation/php/room1.php?device1=1
                //   OR
                // the effective string becomes http://your_IP/homeAutomation/php/room1.php?device1=0

                // Request a string response from the provided URL.
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                        new Response.Listener<String>() { // to listen to the response
                            @Override
                            public void onResponse(String response) { // once we have receive a response
                                status_led.setText(response); // set the response to the status TextView element
                                Toast.makeText(RoomActivity.this, response, Toast.LENGTH_LONG).show(); //display response
                            }
                        }, new Response.ErrorListener() { // listen to error
                    @Override
                    public void onErrorResponse(VolleyError error) { // when error has been received
                        Toast.makeText(RoomActivity.this, error.toString(), Toast.LENGTH_LONG).show(); // display error message after convertiing it to string using toString
                    }
                });
                // Add the request to the RequestQueue.
                queue.add(stringRequest);
            }
            // Volley method ends
        });
        // button onCLickListener ends


        button_mois.setOnClickListener(new View.OnClickListener() { // listens to click of button
            @Override
            public void onClick(View view) { // when button is clicked

                // Volley method (function)
                RequestQueue queue = Volley.newRequestQueue(RoomActivity.this); // build the request queue. The queue which will execute all the requests
                String url ="http://your_ip/homeAutomation/php/mois.txt"; // define the URL which you want to hit

                // Request a string response from the provided URL.
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                        new Response.Listener<String>() { // to listen to the response
                            @Override
                            public void onResponse(String response) { // once we have receive a response
                                status_mois.setText(response); // set the response to the status TextView element
                                Toast.makeText(RoomActivity.this, response, Toast.LENGTH_LONG).show(); //display response
                            }
                        }, new Response.ErrorListener() { // listen to error
                    @Override
                    public void onErrorResponse(VolleyError error) { // when error has been received
                        Toast.makeText(RoomActivity.this, error.toString(), Toast.LENGTH_LONG).show(); // display error message after convertiing it to string using toString
                    }
                });
                // Add the request to the RequestQueue.
                queue.add(stringRequest);
            }
            // Volley method ends
        });
        // button onCLickListener ends
    }
}
