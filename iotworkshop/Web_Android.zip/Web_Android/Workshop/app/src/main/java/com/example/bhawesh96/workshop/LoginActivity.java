package com.example.bhawesh96.workshop;

//imports
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

//defining a public class. Class name should be same as file name. INHERITS the class AppCompatActivity using EXTENDS
public class LoginActivity extends AppCompatActivity {

    EditText username, password; // to reference the EditText elements in the GUI
    Button login;   // to refrence the button element in GUI

    String username_value, password_value;  // to store the values of the EditText elements once the user enters it

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);    // to refrence the LAYOUT file corresponding to this ACTIVITY

        username = (EditText) findViewById(R.id.editText_username); // assign value to the refrence variable of EditText
        password = (EditText) findViewById(R.id.editText_password); // assign value to the refrence variable of EditText

        login = (Button) findViewById(R.id.button_submit);  // assign value to the refrence variable of button

        login.setOnClickListener(new View.OnClickListener() {   // listens to the click of button
            @Override
            public void onClick(View view) {    // once clicked, perform the following
                username_value = username.getText().toString(); // extract value from EditText using getText() and convert to string using toString()
                password_value = password.getText().toString(); // extract value from EditText using getText() and convert to string using toString()

                if(username_value.equals("admin") && password_value.equals("mypass")) { // validation alias : // username_value == "admin" && password_value =="mypass"

                    Toast.makeText(LoginActivity.this, "Welcome", Toast.LENGTH_LONG).show();    // display a temporary message

                    Intent intent = new Intent(LoginActivity.this, RoomActivity.class); // create an INTENT to SHIFT to other screen/activity
                    startActivity(intent);  // execute the intent. As the name says...startActivity();

                } else {    // if the validation fails
                    Toast.makeText(LoginActivity.this, "Login not validated", Toast.LENGTH_LONG).show(); // display error message
                }
            }
       });
    }
}









